import Foundation

//1. Создать протокол «Car» и описать свойства, общие для автомобилей, а также методы действий.
//2. Создать расширения для протокола «Car» и реализовать в них методы конкретных действий с автомобилем: открыть/закрыть окно, запустить/заглушить двигатель и т.д. (по одному методу на действие, реализовывать следует только те действия, реализация которых общая для всех автомобилей).
//3. Создать два класса, имплементирующих протокол «Car» - trunkCar и sportСar. Описать в них свойства, отличающиеся для спортивного автомобиля и цистерны.
//4. Для каждого класса написать расширение, имплементирующее протокол CustomStringConvertible.
//5. Создать несколько объектов каждого класса. Применить к ним различные действия.
//6. Вывести сами объекты в консоль.

enum WindowsState: String {
    case windowsAreOpen = "Окна открыты"
    case windowsAreClosed = "Окна закрыты"
}

enum EngineState: String {
    case engineIsRunning = "Двигатель заведён"
    case engineIsStopped = "Двигатель заглушён"
}

enum HatchState: String {
    case hatchIsOpen = "Люк открыт"
    case hatchIsClosed = "Люк закрыт"
}

enum AutoLoader: String {
    case autoLoaderIsAvaliable = "Имеется автопогрузчик"
    case autoLoaderIsAbsent = "Автопогрузчик отсутствует"
}

enum Spoiler: String {
    case spoilerIsOn = "Имеется спойлер"
    case spoilerIsOff = "Спойлер отсутствует"
}

enum SpareWheels: String {
    case spareWheelsAreSet = "Запасные колеса присутствуют"
    case spareWheelsAreOff = "Запасные колеса отсутствуют"
}

protocol CarProtocol: AnyObject, CustomStringConvertible {      // После CarProtocol пытался поставить class, чтобы в методах расширений
    var mark: String { get }                                    // не писать слово mutating, однако компилятор попросил
    var year: Int { get }                                       // поменять class на AnyObject. Насколько это меняет ситуацию?
    var trunkVolume: Double { get }
    var engineState: EngineState { get set }
    var windowsState: WindowsState { get set }
    
    func changeEngineState(to: EngineState)
    func changeWindowsState(to: WindowsState)
}

extension CarProtocol {
    
    func changeEngineState(to: EngineState) {
        engineState = to
    }
    
    func changeWindowsState(to: WindowsState) {
        windowsState = to
    }
}

class SportCar: CarProtocol {
    
    var mark: String
    var year: Int
    var trunkVolume: Double
    var engineState: EngineState
    var windowsState: WindowsState
    var spoiler: Spoiler
    
    init(mark: String, year: Int, trunkVolume: Double, engineState: EngineState, windowsState: WindowsState, spoiler: Spoiler) {
        self.mark = mark
        self.year = year
        self.trunkVolume = trunkVolume
        self.engineState = engineState
        self.windowsState = windowsState
        self.spoiler = spoiler
    }
    
    func changeSpoilerState(to: Spoiler){
        spoiler = to
    }
}

extension CarProtocol {
    
}

class TrunkCar: CarProtocol {
    
    var mark: String
    var year: Int
    var trunkVolume: Double
    var engineState: EngineState
    var windowsState: WindowsState
    var autoLoader: AutoLoader
    var spareWheels: SpareWheels
    
    
    init(mark: String, year: Int, trunkVolume: Double, engineState: EngineState, windowsState: WindowsState, autoLoader: AutoLoader, spareWheels: SpareWheels) {
        self.mark = mark
        self.year = year
        self.trunkVolume = trunkVolume
        self.engineState = engineState
        self.windowsState = windowsState
        self.autoLoader = autoLoader
        self.spareWheels = spareWheels
    }
    
    func changeAutoLoaderState(to: AutoLoader) {
        autoLoader = to
    }
    
    func changeSpareWheelsState(to: SpareWheels) {
        spareWheels = to
    }
}

extension SportCar {
    var description: String {
        return "Марка авто: \(mark), год выпуска: \(year), объем багажника: \(trunkVolume), состояние двигателя: \(engineState.rawValue), состояние окон: \(windowsState.rawValue), наличие спойлера: \(spoiler.rawValue) "
    }
}

extension TrunkCar {
    var description: String {
        return "Марка авто: \(mark), год выпуска: \(year), объем багажника: \(trunkVolume), состояние двигателя: \(engineState.rawValue), состояние окон: \(windowsState.rawValue), наличие автопогрузчика: \(autoLoader.rawValue), наличие запасных колес: \(spareWheels.rawValue)"
    }
}


var fastestCarAlive = SportCar(mark: "Subaru", year: 2077, trunkVolume: 10, engineState: .engineIsStopped, windowsState: .windowsAreClosed, spoiler: .spoilerIsOff)

print("-----------------------")
print(fastestCarAlive)
fastestCarAlive.changeEngineState(to: .engineIsRunning)
fastestCarAlive.changeWindowsState(to: .windowsAreOpen)
fastestCarAlive.changeSpoilerState(to: .spoilerIsOn)
print(fastestCarAlive)


var biggestTrunk = TrunkCar(mark: "KAMAZ", year: 2049, trunkVolume: 1500, engineState: .engineIsRunning, windowsState: .windowsAreOpen, autoLoader: .autoLoaderIsAvaliable, spareWheels: .spareWheelsAreOff)

print("-----------------------")
print(biggestTrunk)
biggestTrunk.changeEngineState(to: .engineIsStopped)
biggestTrunk.changeWindowsState(to: .windowsAreClosed)
biggestTrunk.changeSpareWheelsState(to: .spareWheelsAreSet)
print(biggestTrunk)
